---
layout: page
title: About
permalink: /about/
---

Webjeda cards is a Bootstrap based theme. Any Bootstrap element can be used in the theme. Read [Webjeda Blog](http://blog.webjeda.com){: target="\_blank"} for jekyll tutorials.

For more themes, visit [jekyll-themes](https://jekyll-themes.com){: target="\_blank"}

**Does the theme deserve a star?**

<a class="github-button" href="https://github.com/sharu725/cards" data-style="mega" data-count-href="/sharu725/cards/stargazers" data-count-api="/repos/sharu725/cards#stargazers_count" data-count-aria-label="# stargazers on GitHub" aria-label="Star sharu725/cards on GitHub">Star</a>

<script async defer src="https://buttons.github.io/buttons.js"></script>
